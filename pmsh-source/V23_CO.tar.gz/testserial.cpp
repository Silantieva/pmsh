#include <iostream>
#include <fstream>

using namespace std;

#include "defns5.h" 

int main (int argc, char ** argv)
{

   nglib::Ng_Mesh *mesh;             // Define pointer to a new Netgen Mesh 
   Ng_STL_Geometry *stl_geom; // Define pointer to STL Geometry
   Ng_Result ng_res;          // Result of Netgen Operations
   int numprocs    ;          // number of processors 
   int  mypid      ;          // mypid 
   char filename[100]  ;   // geometry file
   char *inpfile ;
   int    tp,ts,tv ; 
   int facecount, newFacecount;
   int sumFacecount, sumNewFacecount;
   int numlevels = 0 ; 

   double t1, t2, t3, t4, tpar_, tpar;	
   
   inpfile = argv[1] ;   
   sprintf(filename,"%s.stl",inpfile)  ;
   //numprocs = atoi(argv[2]) ; 
   
   // initialize the Netgen Core library
   Ng_Init();

   // create the mesh structure
   mesh = Ng_NewMesh();

   // Read in the STL File
   stl_geom = Ng_STL_LoadGeometry(filename);
   if(!stl_geom) {
      cout << "MY: Error reading in STL File: " << filename << endl;
        return 1;
   }
   cout << "MY: Successfully loaded STL File: " << filename << endl;


   // Set the Meshing Parameters to be used
   Ng_Meshing_Parameters mp;
   mp.maxh = atof(argv[3]) ;
   mp.fineness = atof(argv[4]) ;
   //mp.maxh = 1e6;
   //mp.fineness = 1.0 ;
   mp.second_order = 0;
   

    printf("paramters: input %s numprocs %d maxh %.3f fineness %.3f\n",
            inpfile, numprocs, mp.maxh, mp.fineness);

   cout << "MY: Initialise the STL Geometry structure...." << endl;
   // timer başlangıç
   ng_res = Ng_STL_InitSTLGeometry(stl_geom);
   if(ng_res != NG_OK) {
      cout << "Error Initialising the STL Geometry....Aborting!!" << endl;
         return 1;
   }
   
   cout << "MY: Start Edge Meshing...." << endl;
   ng_res = Ng_STL_MakeEdges(stl_geom, mesh, &mp);
   if(ng_res != NG_OK) {
      cout << "Error in Edge Meshing....Aborting!!" << endl;
         return 1;
   }

   cout << "MY: Start Surface Meshing...." << endl;
   ng_res = Ng_STL_GenerateSurfaceMesh(stl_geom, mesh, &mp);
   if(ng_res != NG_OK)  {
      cout << "Error in Surface Meshing....Aborting!!" << endl;
         return 1;
   }
   tp = Ng_GetNP(mesh) ; 
   ts = Ng_GetNSE(mesh);
   if (mypid == 0) {
     printf("MY: Global coarse surface mesh - No. of P/S: %d %d\n",tp,ts) ;
   }
   int tp1 = tp;
   int ts1 = ts;

   MPI_Init(&argc,&argv) ;
   MPI_Comm_rank(MPI_COMM_WORLD,&mypid);
   MPI_Comm_size(MPI_COMM_WORLD,&numprocs);

   MPI_Barrier(MPI_COMM_WORLD);
   t4 = MPI_Wtime();

   MPI_Finalize() ;
   exit(0) ;   
}

