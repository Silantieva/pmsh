#include <iostream>
#include <fstream>

using namespace std;

#include "defns5.h" 

int main (int argc, char ** argv)
{

   nglib::Ng_Mesh *mesh;             // Define pointer to a new Netgen Mesh 
   Ng_CSG_Geometry *geom = new Ng_CSG_Geometry(); //loaded geometry

   Ng_Result ng_res;          // Result of Netgen Operations
   int numprocs    ;          // number of processors 
   int  mypid      ;          // mypid 
   char filename[100], geofilename[100]  ;   // geometry file
   char *inpfile ;
   int    tp,ts,tv ; 
   int *geoid;
   int facecount, newFacecount;
   int sumFacecount, sumNewFacecount;
   int numlevels = 0 ; 

   double t1, t2, t3, t4, tpar_, tpar;	
   
   inpfile = argv[1] ;   

   MPI_Init(&argc,&argv) ;
   MPI_Comm_rank(MPI_COMM_WORLD,&mypid);
   MPI_Comm_size(MPI_COMM_WORLD,&numprocs);

   mypid = atoi(argv[2]) ; 
   // initialize the Netgen Core library
   Ng_Init();

   // create the mesh structure
   sprintf(filename,"%s.%d.vol",inpfile,mypid);
   mesh = nglib::Ng_LoadMesh(filename);
   printf("Loaded mesh\n");
   // Set the Meshing Parameters to be used
   Ng_Meshing_Parameters mp;
   mp.maxh = atof(argv[3]) ;
   mp.fineness = atof(argv[4]) ;
   //mp.maxh = 1e6;
   //mp.fineness = 1.0 ;
   mp.second_order = 0;
   sprintf(geofilename,"%s.geo",inpfile);
   ng_res = Ng_CSG_GenerateMesh (geofilename, mesh, geom, mp, nglib::MESH_VOLUME,
                                 &tp, &tv, &ts, geoid); //loaded geometry to geom, generated volume mesh

   sprintf(filename,"vol-%s.%d.vol",inpfile,mypid);
   Ng_SaveMesh(mesh,filename);

   MPI_Finalize() ;
   exit(0) ;   
}

